import { useEffect, useRef, useState } from "react";
import type { Map as MlMap, RasterTileSource, StyleSpecification } from "maplibre-gl";
import { SITES } from "@/data/catalog";
import { AOI, siteInKindGroup, type FlightEvent, type ImagerySource, type ThermalEvent, type WatchBox } from "@/lib/types";
import { useAppStore } from "@/lib/store";
import { cn, snapshotUrl } from "@/lib/utils";

const PARTY_COLOR: Record<string, string> = {
  saf: "#7b93a6",
  rsf: "#b38862",
  mixed: "#9aa08a",
  other_armed: "#8b7d9a",
  civilian: "#7d9a7a",
  unknown: "#8a857c",
};

const CLOSE_KINDS = new Set(["logistics", "airfield", "port", "compound", "hospital", "market"]);

type FC = {
  type: "FeatureCollection";
  features: Array<{
    type: "Feature";
    properties: Record<string, unknown>;
    geometry:
      | { type: "Polygon"; coordinates: number[][][] }
      | { type: "Point"; coordinates: [number, number] };
  }>;
};

function gibsUrl(layer: string, date: string, level: number, ext = "jpg"): string {
  return `https://gibs.earthdata.nasa.gov/wmts/epsg3857/best/${layer}/default/${date}/GoogleMapsCompatible_Level${level}/{z}/{y}/{x}.${ext}`;
}

function hlsUrl(date: string): string {
  return gibsUrl("HLS_S30_Nadir_BRDF_Adjusted_Reflectance", date, 12, "png");
}

function viirsUrl(date: string): string {
  return gibsUrl("VIIRS_NOAA20_CorrectedReflectance_TrueColor", date, 9, "jpg");
}

const S2_CLOUDLESS =
  "https://tiles.maps.eox.at/wmts/1.0.0/s2cloudless-2024_3857/default/g/{z}/{y}/{x}.jpg";

function thermalUrl(date: string): string {
  return `https://gibs.earthdata.nasa.gov/wmts/epsg3857/best/VIIRS_NOAA20_Thermal_Anomalies_375m_All/default/${date}/GoogleMapsCompatible_Level8/{z}/{y}/{x}.png`;
}

function vis(imagery: ImagerySource, id: "hls" | "viirs" | "s2cloudless"): "visible" | "none" {
  if (id === "hls") return imagery === "s2" ? "visible" : "none";
  if (id === "viirs") return imagery === "viirs" ? "visible" : "none";
  return imagery === "s2cloudless" ? "visible" : "none";
}

function hudPad(panelOpen: boolean) {
  return { top: 88, right: panelOpen ? 420 : 56, bottom: 108, left: 16 };
}

function baseStyle(date: string, imagery: ImagerySource): StyleSpecification {
  return {
    version: 8,
    sources: {
      esri: {
        type: "raster",
        tiles: [
          "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",
        ],
        tileSize: 256,
        attribution: "Esri World Imagery",
        maxzoom: 19,
      },
      viirs: {
        type: "raster",
        tiles: [viirsUrl(date)],
        tileSize: 256,
        maxzoom: 9,
        attribution: "NASA GIBS / VIIRS NOAA-20",
      },
      hls: {
        type: "raster",
        tiles: [hlsUrl(date)],
        tileSize: 256,
        maxzoom: 12,
        attribution: "NASA HLS / Sentinel-2 MSI",
      },
      s2cloudless: {
        type: "raster",
        tiles: [S2_CLOUDLESS],
        tileSize: 256,
        maxzoom: 16,
        attribution: "Sentinel-2 cloudless 2024 © EOX / Copernicus",
      },
    },
    layers: [
      { id: "esri", type: "raster", source: "esri" },
      {
        id: "viirs",
        type: "raster",
        source: "viirs",
        maxzoom: 9.4,
        layout: { visibility: vis(imagery, "viirs") },
        paint: {
          "raster-opacity": ["interpolate", ["linear"], ["zoom"], 3, 0.72, 6, 0.92, 9.4, 0],
          "raster-brightness-min": 0.18,
          "raster-contrast": 0.22,
          "raster-saturation": 0.08,
          "raster-fade-duration": 0,
        },
      },
      {
        id: "hls",
        type: "raster",
        source: "hls",
        maxzoom: 12.8,
        layout: { visibility: vis(imagery, "hls") },
        paint: {
          "raster-opacity": ["interpolate", ["linear"], ["zoom"], 4, 1, 12, 1, 12.8, 0],
          "raster-brightness-min": 0.08,
          "raster-contrast": 0.12,
          "raster-fade-duration": 0,
        },
      },
      {
        id: "s2cloudless",
        type: "raster",
        source: "s2cloudless",
        layout: { visibility: vis(imagery, "s2cloudless") },
        paint: {
          "raster-opacity": 1,
          "raster-brightness-min": 0.06,
          "raster-contrast": 0.1,
          "raster-fade-duration": 0,
        },
      },
    ],
  };
}

function boxFc(boxes: WatchBox[]): FC {
  return {
    type: "FeatureCollection",
    features: boxes.map((b) => ({
      type: "Feature",
      properties: { id: b.id, name: b.name, priority: b.priority },
      geometry: {
        type: "Polygon",
        coordinates: [[
          [b.west, b.south],
          [b.east, b.south],
          [b.east, b.north],
          [b.west, b.north],
          [b.west, b.south],
        ]],
      },
    })),
  };
}

function siteFc(partyOf: (id: string) => string, kindFilter = "all"): FC {
  return {
    type: "FeatureCollection",
    features: SITES.filter((s) => siteInKindGroup(s.kind, kindFilter)).map((s) => ({
      type: "Feature",
      properties: {
        id: s.id,
        name: s.name,
        kind: s.kind,
        party: partyOf(s.id),
        status: s.status,
      },
      geometry: { type: "Point", coordinates: [s.lon, s.lat] },
    })),
  };
}

function pointFc<T extends { id: string; lat: number; lon: number }>(
  rows: T[],
  extra: (r: T) => Record<string, unknown>,
): FC {
  return {
    type: "FeatureCollection",
    features: rows.map((r) => ({
      type: "Feature",
      properties: { id: r.id, ...extra(r) },
      geometry: { type: "Point", coordinates: [r.lon, r.lat] },
    })),
  };
}

function pct(lat: number, lon: number) {
  return {
    left: `${((lon - AOI.west) / (AOI.east - AOI.west)) * 100}%`,
    top: `${((AOI.north - lat) / (AOI.north - AOI.south)) * 100}%`,
  };
}

function StaticSatellite({
  date,
  boxes,
  firms,
  flights,
  onPick,
}: {
  date: string;
  boxes: WatchBox[];
  firms: ThermalEvent[];
  flights: FlightEvent[];
  onPick: (id: string) => void;
}) {
  const [src, setSrc] = useState(snapshotUrl(date, AOI));
  useEffect(() => {
    setSrc(snapshotUrl(date, AOI));
  }, [date]);
  const partyOf = useAppStore((s) => s.partyOverrides);

  return (
    <div className="absolute inset-0 overflow-hidden bg-bg">
      <img
        src={src}
        alt="NASA VIIRS true-color mosaic of Sudan and adjacent corridors"
        className="h-full w-full object-cover"
        onError={() => setSrc("/sudan-viirs.jpg")}
      />
      <svg className="pointer-events-none absolute inset-0 h-full w-full" viewBox="0 0 100 100" preserveAspectRatio="none">
        {boxes.map((b) => {
          const x = ((b.west - AOI.west) / (AOI.east - AOI.west)) * 100;
          const y = ((AOI.north - b.north) / (AOI.north - AOI.south)) * 100;
          const w = ((b.east - b.west) / (AOI.east - AOI.west)) * 100;
          const h = ((b.north - b.south) / (AOI.north - AOI.south)) * 100;
          return (
            <rect
              key={b.id}
              x={x}
              y={y}
              width={w}
              height={h}
              fill="rgba(236,232,225,0.06)"
              stroke="rgba(236,232,225,0.4)"
              strokeWidth={0.15}
              strokeDasharray="0.6 0.5"
            />
          );
        })}
      </svg>
      {firms.map((f) => (
        <span
          key={f.id}
          className="pointer-events-none absolute size-2 -translate-x-1/2 -translate-y-1/2 rounded-full bg-thermal shadow-[0_0_10px_#c4894a]"
          style={pct(f.lat, f.lon)}
        />
      ))}
      {flights.map((f) => (
        <span
          key={f.id}
          className="pointer-events-none absolute size-2 -translate-x-1/2 -translate-y-1/2 rotate-45 border border-bg bg-fg"
          style={pct(f.lat, f.lon)}
        />
      ))}
      {SITES.map((s) => {
        const party = partyOf[s.id]?.party ?? s.party;
        return (
          <button
            key={s.id}
            type="button"
            title={s.name}
            onClick={() => onPick(s.id)}
            className="absolute size-3 -translate-x-1/2 -translate-y-1/2 rounded-full border border-bg shadow"
            style={{
              ...pct(s.lat, s.lon),
              background: PARTY_COLOR[party] ?? PARTY_COLOR.unknown,
            }}
          />
        );
      })}
    </div>
  );
}

interface Props {
  boxes: WatchBox[];
  firms: ThermalEvent[];
  flights: FlightEvent[];
  panelOpen?: boolean;
}

export function MapCanvas({ boxes, firms, flights, panelOpen = false }: Props) {
  const host = useRef<HTMLDivElement>(null);
  const wrap = useRef<HTMLDivElement>(null);
  const mapRef = useRef<MlMap | null>(null);
  const ready = useRef(false);
  const hoverPopup = useRef<{ remove: () => void } | null>(null);
  const [engine, setEngine] = useState<"static" | "gl">("static");
  const [cursor, setCursor] = useState("—");
  const layers = useAppStore((s) => s.layers);
  const imagery = useAppStore((s) => s.imagery);
  const date = useAppStore((s) => s.date);
  const selectedSiteId = useAppStore((s) => s.selectedSiteId);
  const setSelectedSite = useAppStore((s) => s.setSelectedSite);
  const partyOverrides = useAppStore((s) => s.partyOverrides);
  const partyFilter = useAppStore((s) => s.partyFilter);
  const kindFilter = useAppStore((s) => s.kindFilter);
  const focusedBoxId = useAppStore((s) => s.focusedBoxId);
  const yardsZoom = useAppStore((s) => s.yardsZoom);
  const clearYardsZoom = useAppStore((s) => s.clearYardsZoom);

  useEffect(() => {
    if (!host.current) return;
    let cancelled = false;
    let map: MlMap | null = null;
    let ro: ResizeObserver | null = null;
    let onCmd: ((ev: Event) => void) | null = null;

    void import("maplibre-gl")
      .then((maplibregl) => {
        if (cancelled || !host.current) return;
        const { Map, NavigationControl, ScaleControl, Popup } = maplibregl;
        try {
          maplibregl.setWorkerCount?.(1);
        } catch {
          /* worker optional */
        }
        const state = useAppStore.getState();
        map = new Map({
          container: host.current,
          style: baseStyle(state.date, state.imagery),
          center: AOI.center,
          zoom: 5.45,
          minZoom: 3.5,
          maxZoom: 18.5,
          attributionControl: { compact: true },
          maxPitch: 0,
        });
        map.addControl(new NavigationControl({ showCompass: false }), "bottom-left");
        map.addControl(new ScaleControl({ maxWidth: 110, unit: "metric" }), "bottom-left");
        map.setPadding(hudPad(false));
        mapRef.current = map;

        const boxesNow = boxes;
        const firmsNow = firms;
        const flightsNow = flights;
        const overridesNow = state.partyOverrides;
        const kindNow = state.kindFilter;

        map.on("load", () => {
          if (!map || cancelled) return;
          map.resize();

          map.addSource("thermal-raster", {
            type: "raster",
            tiles: [thermalUrl(state.date)],
            tileSize: 256,
            maxzoom: 8,
            attribution: "NASA GIBS thermal anomalies",
          });
          map.addLayer({
            id: "thermal-raster",
            type: "raster",
            source: "thermal-raster",
            maxzoom: 8.5,
            layout: { visibility: state.layers.thermalRaster ? "visible" : "none" },
            paint: { "raster-opacity": 0.85 },
          });

          map.addSource("boxes", { type: "geojson", data: boxFc(boxesNow) });
          map.addLayer({
            id: "boxes-fill",
            type: "fill",
            source: "boxes",
            paint: {
              "fill-color": "#d8d2c6",
              "fill-opacity": ["match", ["get", "priority"], "border", 0.04, 0.07],
            },
          });
          map.addLayer({
            id: "boxes-line",
            type: "line",
            source: "boxes",
            paint: {
              "line-color": "#d8d2c6",
              "line-opacity": 0.5,
              "line-width": 1.4,
              "line-dasharray": [2, 2],
            },
          });

          map.addSource("firms", {
            type: "geojson",
            data: pointFc(firmsNow, (r) => ({ klass: r.klass, frp: r.frp, live: !!r.live })),
          });
          map.addLayer({
            id: "firms-glow",
            type: "circle",
            source: "firms",
            paint: {
              "circle-radius": ["interpolate", ["linear"], ["get", "frp"], 0, 6, 40, 14],
              "circle-color": "#c4894a",
              "circle-opacity": 0.28,
              "circle-blur": 0.5,
            },
          });
          map.addLayer({
            id: "firms-core",
            type: "circle",
            source: "firms",
            paint: {
              "circle-radius": 3.5,
              "circle-color": "#c4894a",
              "circle-stroke-width": 1,
              "circle-stroke-color": "#12110f",
            },
          });

          map.addSource("flights", {
            type: "geojson",
            data: pointFc(flightsNow, (r) => ({
              category: r.category,
              relevant: r.relevant,
              hex: r.hex,
            })),
          });
          map.addLayer({
            id: "flights",
            type: "circle",
            source: "flights",
            paint: {
              "circle-radius": 5,
              "circle-color": "#ece8e1",
              "circle-stroke-width": 1.5,
              "circle-stroke-color": "#12110f",
            },
          });

          const partyOf = (id: string) =>
            overridesNow[id]?.party ?? SITES.find((s) => s.id === id)?.party ?? "unknown";
          map.addSource("sites", { type: "geojson", data: siteFc(partyOf, kindNow) });
          map.addLayer({
            id: "sites",
            type: "circle",
            source: "sites",
            paint: {
              "circle-radius": ["interpolate", ["linear"], ["zoom"], 4, 3.2, 5.5, 5.4, 8, 7.5, 12, 9, 16, 12],
              "circle-color": [
                "match",
                ["get", "party"],
                "saf",
                PARTY_COLOR.saf ?? "#8a857c",
                "rsf",
                PARTY_COLOR.rsf ?? "#8a857c",
                "mixed",
                PARTY_COLOR.mixed ?? "#8a857c",
                "other_armed",
                PARTY_COLOR.other_armed ?? "#8a857c",
                "civilian",
                PARTY_COLOR.civilian ?? "#8a857c",
                PARTY_COLOR.unknown ?? "#8a857c",
              ],
              "circle-stroke-width": 1.8,
              "circle-stroke-color": "#12110f",
            },
          });

          ready.current = true;
          setEngine("gl");
        });

        map.on("click", "sites", (e) => {
          const feat = e.features?.[0];
          const id = feat?.properties?.id as string | undefined;
          if (id) setSelectedSite(id);
        });
        map.on("mouseenter", "sites", (e) => {
          if (!map) return;
          map.getCanvas().style.cursor = "pointer";
          const feat = e.features?.[0];
          const name = feat?.properties?.name as string | undefined;
          if (feat?.geometry && feat.geometry.type === "Point" && name) {
            hoverPopup.current?.remove();
            const [lon, lat] = feat.geometry.coordinates as [number, number];
            hoverPopup.current = new Popup({ closeButton: false, offset: 14, className: "sr-popup" })
              .setLngLat([lon, lat])
              .setHTML(`<div style="font:500 12px/1.3 'IBM Plex Sans',system-ui">${name}</div>`)
              .addTo(map);
          }
        });
        map.on("mouseleave", "sites", () => {
          if (map) map.getCanvas().style.cursor = "";
          hoverPopup.current?.remove();
          hoverPopup.current = null;
        });
        map.on("mousemove", (e) => {
          const z = map?.getZoom() ?? 0;
          setCursor(`${e.lngLat.lat.toFixed(4)}°  ${e.lngLat.lng.toFixed(4)}°  z${z.toFixed(1)}`);
        });
        const onMapCmd = (ev: Event) => {
          const cmd = (ev as CustomEvent<"in" | "out">).detail;
          if (!map) return;
          if (cmd === "in") map.zoomIn({ duration: 250 });
          if (cmd === "out") map.zoomOut({ duration: 250 });
        };
        onCmd = onMapCmd;
        window.addEventListener("sahel-map", onMapCmd);

        if (wrap.current && typeof ResizeObserver !== "undefined") {
          ro = new ResizeObserver(() => map?.resize());
          ro.observe(wrap.current);
        }
        requestAnimationFrame(() => map?.resize());
      })
      .catch((err) => {
        console.warn("[map] MapLibre failed, keeping static satellite", err);
        setEngine("static");
      });

    const failSafe = window.setTimeout(() => {
      if (!ready.current) setEngine("static");
    }, 5000);

    return () => {
      cancelled = true;
      ready.current = false;
      window.clearTimeout(failSafe);
      if (onCmd) window.removeEventListener("sahel-map", onCmd);
      hoverPopup.current?.remove();
      ro?.disconnect();
      map?.remove();
      mapRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    const map = mapRef.current;
    if (!map || !ready.current) return;
    map.setPadding(hudPad(panelOpen));
    map.resize();
  }, [panelOpen]);

  useEffect(() => {
    const map = mapRef.current;
    if (!map || !ready.current) return;
    const visOn = (on: boolean): "visible" | "none" => (on ? "visible" : "none");
    const setVis = (id: string, on: boolean) => {
      if (map.getLayer(id)) map.setLayoutProperty(id, "visibility", visOn(on));
    };
    setVis("viirs", imagery === "viirs");
    setVis("hls", imagery === "s2");
    setVis("s2cloudless", imagery === "s2cloudless");
    setVis("thermal-raster", layers.thermalRaster);
    setVis("boxes-fill", layers.boxes);
    setVis("boxes-line", layers.boxes);
    setVis("firms-glow", layers.firms);
    setVis("firms-core", layers.firms);
    setVis("flights", layers.flights);
    setVis("sites", layers.sites);
  }, [layers, imagery]);

  useEffect(() => {
    const map = mapRef.current;
    if (!map || !ready.current) return;
    const v = map.getSource("viirs") as RasterTileSource | undefined;
    const h = map.getSource("hls") as RasterTileSource | undefined;
    const t = map.getSource("thermal-raster") as RasterTileSource | undefined;
    v?.setTiles?.([viirsUrl(date)]);
    h?.setTiles?.([hlsUrl(date)]);
    t?.setTiles?.([thermalUrl(date)]);
  }, [date]);

  useEffect(() => {
    const map = mapRef.current;
    if (!map || !ready.current) return;
    const src = map.getSource("boxes");
    if (src && "setData" in src) (src as { setData: (d: FC) => void }).setData(boxFc(boxes));
  }, [boxes]);

  useEffect(() => {
    const map = mapRef.current;
    if (!map || !ready.current) return;
    const src = map.getSource("firms");
    if (src && "setData" in src)
      (src as { setData: (d: FC) => void }).setData(
        pointFc(firms, (r) => ({ klass: r.klass, frp: r.frp, live: !!r.live })),
      );
  }, [firms]);

  useEffect(() => {
    const map = mapRef.current;
    if (!map || !ready.current) return;
    const src = map.getSource("flights");
    if (src && "setData" in src)
      (src as { setData: (d: FC) => void }).setData(
        pointFc(flights, (r) => ({ category: r.category, relevant: r.relevant, hex: r.hex })),
      );
  }, [flights]);

  useEffect(() => {
    const map = mapRef.current;
    if (!map || !ready.current) return;
    const partyOf = (id: string) =>
      partyOverrides[id]?.party ?? SITES.find((s) => s.id === id)?.party ?? "unknown";
    const data = siteFc(partyOf, kindFilter);
    if (partyFilter !== "all") {
      data.features = data.features.filter((f) => f.properties.party === partyFilter);
    }
    const src = map.getSource("sites");
    if (src && "setData" in src) (src as { setData: (d: FC) => void }).setData(data);
  }, [partyOverrides, partyFilter, kindFilter]);

  useEffect(() => {
    const map = mapRef.current;
    if (!map || !selectedSiteId) return;
    const site = SITES.find((s) => s.id === selectedSiteId);
    if (!site) return;
    const close = yardsZoom || CLOSE_KINDS.has(site.kind);
    map.flyTo({
      center: [site.lon, site.lat],
      zoom: yardsZoom ? 17.2 : close ? 16.1 : 14.6,
      duration: 900,
      essential: true,
    });
    if (yardsZoom) clearYardsZoom();
  }, [selectedSiteId, yardsZoom, clearYardsZoom]);

  useEffect(() => {
    const map = mapRef.current;
    if (!map || !focusedBoxId) return;
    const box = boxes.find((b) => b.id === focusedBoxId);
    if (!box) return;
    map.fitBounds(
      [
        [box.west, box.south],
        [box.east, box.north],
      ],
      { padding: 48, duration: 800, maxZoom: 11.5 },
    );
  }, [focusedBoxId, boxes]);

  return (
    <div ref={wrap} className="absolute inset-0 bg-bg">
      {engine !== "gl" ? (
        <StaticSatellite
          date={date}
          boxes={boxes}
          firms={firms}
          flights={flights}
          onPick={setSelectedSite}
        />
      ) : null}
      <div
        ref={host}
        className={cn("h-full w-full", engine !== "gl" && "pointer-events-none opacity-0")}
      />
      <div className="pointer-events-none absolute bottom-28 left-3 hidden rounded-full border border-border bg-bg/80 px-2.5 py-1 font-mono text-[11px] tabular-nums text-muted md:block">
        {cursor}
        <span className="mx-1.5 text-subtle">·</span>
        {imagery === "s2"
          ? `S2 HLS ${date}`
          : imagery === "viirs"
            ? `VIIRS ${date}`
            : imagery === "s2cloudless"
              ? "S2 cloudless 2024"
              : "High-res"}
      </div>
    </div>
  );
}

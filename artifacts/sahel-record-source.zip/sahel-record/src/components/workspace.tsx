import { useEffect, useMemo, useRef, useState } from "react";
import { Link } from "@tanstack/react-router";
import { AlertTriangle, CircleHelp, FileText, Layers, Map as MapIcon, Minus, Plus, RefreshCw, Search, Satellite } from "lucide-react";
import { ALERTS, OBSERVATIONS, SITES } from "@/data/catalog";
import { ingestLive } from "@/lib/changelog";
import { getLiveBundle } from "@/lib/live";
import { IMAGERY, siteInKindGroup, type FlightEvent, type LiveBundle, type LiveMeta, type ReviewState, type ThermalEvent } from "@/lib/types";
import { useAppStore, useVisibleBoxes } from "@/lib/store";
import { cn, daysAgo, mapCommand } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { MapCanvas } from "@/components/map-canvas";
import { LeftRail, RightRail, type MobileTab } from "@/components/rails";

const JUMP = [
  { id: "hsss", label: "Khartoum" },
  { id: "wad-madani", label: "Wad Madani" },
  { id: "hsfs", label: "El Fasher" },
  { id: "hspn", label: "Port Sudan" },
  { id: "hsnn", label: "Nyala" },
  { id: "hsgn", label: "Geneina" },
] as const;

function MetaChip({ label, meta }: { label: string; meta: LiveMeta | null }) {
  const tone =
    meta?.status === "ok"
      ? "text-civilian"
      : meta?.status === "gap" || meta?.status === "stale"
        ? "text-thermal"
        : meta?.status === "error"
          ? "text-damage"
          : "text-muted";
  return (
    <span className={cn("font-mono text-[11px] tabular-nums", tone)}>
      {label} {meta ? meta.status : "…"}
      {meta?.fetchedAt ? ` · ${meta.fetchedAt.slice(11, 16)}Z` : ""}
    </span>
  );
}

function DateStrip({
  date,
  setDate,
  compareDate,
  setCompareDate,
  dated,
  swipeOn,
  setSwipeOn,
  onPickDate,
}: {
  date: string;
  setDate: (d: string) => void;
  compareDate: string;
  setCompareDate: (d: string) => void;
  dated: boolean;
  swipeOn: boolean;
  setSwipeOn: (v: boolean) => void;
  onPickDate: (d: string) => void;
}) {
  const days = useMemo(() => Array.from({ length: 16 }, (_, i) => daysAgo(15 - i)), []);
  return (
    <div className="hud-panel flex w-full items-center gap-3 px-3 py-2">
      <input
        type="date"
        value={date}
        onChange={(e) => onPickDate(e.target.value)}
        className="h-9 w-[9.5rem] rounded-lg border border-border bg-raised px-2 font-mono text-xs tabular-nums"
        aria-label="Browse date"
      />
      <div className="flex min-w-0 flex-1 items-center gap-1 overflow-x-auto">
        {days.map((d) => (
          <button
            key={d}
            type="button"
            onClick={() => onPickDate(d)}
            className={cn(
              "h-8 shrink-0 rounded-md px-2 font-mono text-[11px] tabular-nums",
              date === d ? "bg-accent text-accent-fg" : "text-muted hover:bg-raised hover:text-fg",
            )}
          >
            {d.slice(5)}
          </button>
        ))}
      </div>
      <label className="hidden shrink-0 items-center gap-2 text-xs text-muted sm:flex">
        <input type="checkbox" checked={swipeOn} onChange={(e) => setSwipeOn(e.target.checked)} />
        Compare
      </label>
      {swipeOn ? (
        <input
          type="date"
          value={compareDate}
          onChange={(e) => setCompareDate(e.target.value)}
          className="hidden h-9 w-[9.5rem] rounded-lg border border-border bg-raised px-2 font-mono text-xs tabular-nums sm:block"
          aria-label="Compare date"
        />
      ) : null}
      {!dated ? (
        <p className="hidden max-w-[14rem] shrink-0 text-[11px] leading-snug text-subtle lg:block">
          Picking a date switches to Sentinel-2 so the day actually means something.
        </p>
      ) : null}
    </div>
  );
}

export function Workspace() {
  const [tab, setTab] = useState<MobileTab>("log");
  const [live, setLive] = useState<LiveBundle | null>(null);
  const [liveError, setLiveError] = useState<string | null>(null);
  const [note, setNote] = useState("");
  const [boxOpen, setBoxOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [leftOpen, setLeftOpen] = useState(false);
  const [sweeping, setSweeping] = useState(false);
  const [sweepNote, setSweepNote] = useState<string | null>(null);
  const searchRef = useRef<HTMLInputElement>(null);
  const [boxForm, setBoxForm] = useState({
    name: "",
    west: "32.2",
    south: "15.3",
    east: "32.8",
    north: "15.9",
  });

  const selectedSiteId = useAppStore((s) => s.selectedSiteId);
  const selectedAlertId = useAppStore((s) => s.selectedAlertId);
  const setSelectedSite = useAppStore((s) => s.setSelectedSite);
  const setSelectedAlert = useAppStore((s) => s.setSelectedAlert);
  const partyFilter = useAppStore((s) => s.partyFilter);
  const setPartyFilter = useAppStore((s) => s.setPartyFilter);
  const kindFilter = useAppStore((s) => s.kindFilter);
  const setKindFilter = useAppStore((s) => s.setKindFilter);
  const reviewFilter = useAppStore((s) => s.reviewFilter);
  const setReviewFilter = useAppStore((s) => s.setReviewFilter);
  const layers = useAppStore((s) => s.layers);
  const toggleLayer = useAppStore((s) => s.toggleLayer);
  const imagery = useAppStore((s) => s.imagery);
  const setImagery = useAppStore((s) => s.setImagery);
  const date = useAppStore((s) => s.date);
  const setDate = useAppStore((s) => s.setDate);
  const compareDate = useAppStore((s) => s.compareDate);
  const setCompareDate = useAppStore((s) => s.setCompareDate);
  const swipeOn = useAppStore((s) => s.swipeOn);
  const setSwipeOn = useAppStore((s) => s.setSwipeOn);
  const query = useAppStore((s) => s.query);
  const setQuery = useAppStore((s) => s.setQuery);
  const reviews = useAppStore((s) => s.reviews);
  const reviewAlert = useAppStore((s) => s.reviewAlert);
  const partyOverrides = useAppStore((s) => s.partyOverrides);
  const overrideParty = useAppStore((s) => s.overrideParty);
  const addBox = useAppStore((s) => s.addBox);
  const removeBox = useAppStore((s) => s.removeBox);
  const hideDefaultBox = useAppStore((s) => s.hideDefaultBox);
  const audit = useAppStore((s) => s.audit);
  const replaceLog = useAppStore((s) => s.replaceLog);
  const changeLogCount = useAppStore((s) => s.changeLog.length);
  const setLastSweepAt = useAppStore((s) => s.setLastSweepAt);
  const helpOpen = useAppStore((s) => s.helpOpen);
  const setHelpOpen = useAppStore((s) => s.setHelpOpen);
  const boxes = useVisibleBoxes();

  function applyLive(b: LiveBundle, announce: boolean) {
    setLive(b);
    setLiveError(null);
    const { next, added } = ingestLive(b, useAppStore.getState().changeLog);
    replaceLog(next);
    setLastSweepAt(new Date().toISOString());
    if (announce) {
      setSweepNote(added ? `${added} new log rows` : "Sweep finished · no new rows");
      window.setTimeout(() => setSweepNote(null), 4000);
    }
  }

  useEffect(() => {
    let cancelled = false;
    const load = (announce: boolean) => {
      setSweeping(true);
      getLiveBundle()
        .then((b) => {
          if (!cancelled) applyLive(b, announce);
        })
        .catch((err: unknown) => {
          if (!cancelled) setLiveError(err instanceof Error ? err.message : "Live ingest failed");
        })
        .finally(() => {
          if (!cancelled) setSweeping(false);
        });
    };
    const last = useAppStore.getState().lastSweepAt;
    const stale = !last || Date.now() - Date.parse(last) > 6 * 60 * 60 * 1000;
    load(stale);
    const id = window.setInterval(() => load(true), 6 * 60 * 60 * 1000);
    return () => {
      cancelled = true;
      window.clearInterval(id);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        setSelectedAlert(null);
        setSelectedSite(null);
        setSearchOpen(false);
      }
      if (e.key === "/" && !(e.target instanceof HTMLInputElement) && !(e.target instanceof HTMLTextAreaElement)) {
        e.preventDefault();
        searchRef.current?.focus();
        setSearchOpen(true);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [setSelectedAlert, setSelectedSite]);

  const firms: ThermalEvent[] = live?.firms ?? [];
  const flights: FlightEvent[] = live?.flights ?? [];

  const sites = useMemo(() => {
    return SITES.filter((s) => {
      const party = partyOverrides[s.id]?.party ?? s.party;
      if (partyFilter !== "all" && party !== partyFilter) return false;
      if (!siteInKindGroup(s.kind, kindFilter)) return false;
      return true;
    });
  }, [partyFilter, partyOverrides, kindFilter]);

  const alerts = useMemo(() => {
    return ALERTS.filter((a) => {
      const state = reviews[a.id]?.state ?? a.review;
      if (reviewFilter !== "all" && state !== reviewFilter) return false;
      if (partyFilter !== "all") {
        const hit = a.siteIds.some((id) => {
          const site = SITES.find((s) => s.id === id);
          return (partyOverrides[id]?.party ?? site?.party) === partyFilter;
        });
        if (!hit) return false;
      }
      return true;
    });
  }, [reviewFilter, partyFilter, partyOverrides, reviews]);

  const searchHits = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (q.length < 2) return { siteHits: [] as typeof SITES, alertHits: [] as typeof ALERTS };
    const siteHits = SITES.filter(
      (s) => s.name.toLowerCase().includes(q) || s.admin1.toLowerCase().includes(q) || s.kind.includes(q),
    ).slice(0, 6);
    const alertHits = ALERTS.filter((a) => a.title.toLowerCase().includes(q)).slice(0, 4);
    return { siteHits, alertHits };
  }, [query]);

  const selectedSite = SITES.find((s) => s.id === selectedSiteId) ?? null;
  const selectedAlert = ALERTS.find((a) => a.id === selectedAlertId) ?? null;
  const siteObs = selectedSite ? OBSERVATIONS.filter((o) => o.siteId === selectedSite.id) : [];
  const siteParty = selectedSite ? (partyOverrides[selectedSite.id]?.party ?? selectedSite.party) : "unknown";
  const panelOpen = Boolean(selectedSite || selectedAlert);

  function applyReview(state: ReviewState) {
    if (!selectedAlert) return;
    reviewAlert(selectedAlert.id, state, note, selectedAlert.confidence);
    setNote("");
  }

  function pickDate(d: string) {
    if (!IMAGERY[imagery].dated) setImagery("s2");
    setDate(d);
  }

  function sweepNow() {
    setSweeping(true);
    getLiveBundle()
      .then((b) => applyLive(b, true))
      .catch((err: unknown) => setLiveError(err instanceof Error ? err.message : "Live ingest failed"))
      .finally(() => setSweeping(false));
  }

  const railProps = {
    date, compareDate, setDate, setCompareDate, swipeOn, setSwipeOn,
    layers, toggleLayer, imagery, setImagery, partyFilter, setPartyFilter, query, setQuery,
    boxes, boxOpen, setBoxOpen, boxForm, setBoxForm, addBox, removeBox, hideDefaultBox,
    flights, firms,
  };

  const rightProps = {
    alerts, sites, selectedAlert, selectedSite, siteParty, siteObs, reviews,
    note, setNote, applyReview, setSelectedAlert, setSelectedSite,
    reviewFilter, setReviewFilter, overrideParty, flights, live, liveError, audit,
  };

  return (
    <div className="relative h-dvh overflow-hidden bg-bg text-fg">
      <MapCanvas boxes={boxes} firms={firms} flights={flights} panelOpen={panelOpen} />

      <div className="pointer-events-none absolute inset-x-0 top-0 z-20 p-3">
        <div className="flex items-start gap-2">
          <Link
            to="/"
            className="hud-panel pointer-events-auto flex items-center gap-2.5 px-3 py-2"
          >
            <span className="flex size-8 items-center justify-center rounded-full border border-accent/40 text-accent">
              <Satellite className="size-4" />
            </span>
            <span className="min-w-0">
              <span className="block font-display text-base font-semibold leading-tight tracking-tight">
                Sahel Record
              </span>
              <span className="hidden text-[11px] text-muted sm:block">Sudan archive · documentation only</span>
            </span>
          </Link>

          <div className="pointer-events-auto relative min-w-0 flex-1">
            <label className="hud-panel relative block">
              <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-subtle" />
              <input
                ref={searchRef}
                value={query}
                onChange={(e) => {
                  setQuery(e.target.value);
                  setSearchOpen(true);
                }}
                onFocus={() => setSearchOpen(true)}
                placeholder="Jump to a site or alert  ·  /"
                className="h-11 w-full bg-transparent pl-10 pr-3 text-sm text-fg placeholder:text-subtle"
              />
            </label>
            {searchOpen && query.trim().length >= 2 && (searchHits.siteHits.length + searchHits.alertHits.length) > 0 ? (
              <div className="hud-panel absolute inset-x-0 top-[calc(100%+6px)] z-30 overflow-hidden py-1">
                {searchHits.siteHits.map((s) => (
                  <button
                    key={s.id}
                    type="button"
                    className="flex w-full items-center justify-between px-3 py-2 text-left text-sm hover:bg-raised"
                    onClick={() => {
                      setSelectedSite(s.id);
                      setSelectedAlert(null);
                      setQuery("");
                      setSearchOpen(false);
                    }}
                  >
                    <span>{s.name}</span>
                    <span className="text-xs text-subtle">{s.kind} · {s.admin1}</span>
                  </button>
                ))}
                {searchHits.alertHits.map((a) => (
                  <button
                    key={a.id}
                    type="button"
                    className="flex w-full items-center justify-between px-3 py-2 text-left text-sm hover:bg-raised"
                    onClick={() => {
                      setSelectedAlert(a.id);
                      const first = a.siteIds[0];
                      if (first) setSelectedSite(first);
                      setQuery("");
                      setSearchOpen(false);
                    }}
                  >
                    <span>{a.title}</span>
                    <span className="text-xs text-subtle">alert</span>
                  </button>
                ))}
              </div>
            ) : null}
          </div>

          <nav className="hud-panel pointer-events-auto hidden items-center gap-1 p-1 sm:flex">
            <button
              type="button"
              onClick={() => setHelpOpen(true)}
              className="rounded-lg px-2.5 py-2 text-xs text-muted hover:bg-raised hover:text-fg"
            >
              How this works
            </button>
            <Link to="/methods" className="rounded-lg px-2.5 py-2 text-xs text-muted hover:bg-raised hover:text-fg">Methods</Link>
            <Link to="/ethics" className="rounded-lg px-2.5 py-2 text-xs text-muted hover:bg-raised hover:text-fg">Ethics</Link>
            <Link to="/sop" className="rounded-lg px-2.5 py-2 text-xs text-muted hover:bg-raised hover:text-fg">SOP</Link>
          </nav>
        </div>

        <div className="mt-2 flex flex-wrap items-center gap-2">
          <div className="pointer-events-auto hidden flex-wrap gap-1 md:flex">
            {JUMP.map((j) => (
              <button
                key={j.id}
                type="button"
                onClick={() => {
                  setSelectedAlert(null);
                  setSelectedSite(j.id);
                }}
                className={cn(
                  "h-8 rounded-full border border-border bg-bg/70 px-3 text-xs text-muted backdrop-blur-sm hover:text-fg",
                  selectedSiteId === j.id && "border-accent bg-accent text-accent-fg",
                )}
              >
                {j.label}
              </button>
            ))}
          </div>
          <div className="hud-panel pointer-events-auto ml-auto hidden items-center gap-1 p-1 md:flex">
            {(["s2cloudless", "s2", "viirs", "hires"] as const).map((id) => (
              <button
                key={id}
                type="button"
                onClick={() => setImagery(id)}
                title={IMAGERY[id].note}
                className={cn(
                  "h-8 rounded-lg px-3 text-xs",
                  imagery === id ? "bg-accent text-accent-fg" : "text-muted hover:bg-raised hover:text-fg",
                )}
              >
                {IMAGERY[id].label}
              </button>
            ))}
          </div>
          <div className="hud-panel pointer-events-auto hidden items-center gap-3 px-3 py-1.5 lg:flex">
            <span className="font-mono text-[11px] tabular-nums text-muted">
              {SITES.length} pins · {changeLogCount} records
            </span>
            <MetaChip label="FIRMS" meta={live?.firmsMeta ?? null} />
            <MetaChip label="ADS-B" meta={live?.flightsMeta ?? null} />
            <Badge className="border-damage/40 text-damage">Docs only</Badge>
          </div>
        </div>
      </div>

      <div className="pointer-events-none absolute bottom-24 left-3 top-36 z-20 hidden w-60 md:block">
        <div className="pointer-events-auto mb-2 flex flex-wrap items-center gap-1">
          <button
            type="button"
            className="h-8 rounded-full border border-border bg-bg/80 px-3 text-xs text-muted hover:text-fg"
            onClick={() => setLeftOpen((v) => !v)}
          >
            {leftOpen ? "Hide layers" : "Layers"}
          </button>
          <button
            type="button"
            aria-label="Zoom in"
            className="flex size-8 items-center justify-center rounded-full border border-border bg-bg/80 text-muted hover:text-fg"
            onClick={() => mapCommand("in")}
          >
            <Plus className="size-3.5" />
          </button>
          <button
            type="button"
            aria-label="Zoom out"
            className="flex size-8 items-center justify-center rounded-full border border-border bg-bg/80 text-muted hover:text-fg"
            onClick={() => mapCommand("out")}
          >
            <Minus className="size-3.5" />
          </button>
          <button
            type="button"
            className="flex h-8 items-center gap-1.5 rounded-full border border-border bg-bg/80 px-3 text-xs text-muted hover:text-fg"
            onClick={sweepNow}
            disabled={sweeping}
          >
            <RefreshCw className={cn("size-3.5", sweeping && "animate-spin")} />
            {sweeping ? "Sweeping" : "Sweep now"}
          </button>
        </div>
        {sweepNote ? (
          <p className="pointer-events-none mb-2 rounded-full border border-border bg-bg/80 px-3 py-1 text-[11px] text-fg">
            {sweepNote}
          </p>
        ) : liveError ? (
          <p className="pointer-events-none mb-2 rounded-full border border-damage/40 bg-bg/80 px-3 py-1 text-[11px] text-damage">
            {liveError}
          </p>
        ) : null}
        {leftOpen ? (
          <div className="hud-panel pointer-events-auto h-[min(100%,calc(100dvh-16rem))] overflow-hidden">
            <LeftRail overlay {...railProps} />
          </div>
        ) : null}
      </div>

      <div className="pointer-events-none absolute bottom-24 right-3 top-36 z-20 hidden w-[24.5rem] lg:block">
        <div className="hud-panel pointer-events-auto flex h-full flex-col overflow-hidden">
          <RightRail {...rightProps} />
        </div>
      </div>

      <div className="pointer-events-none absolute inset-x-0 bottom-0 z-20 hidden p-3 md:block">
        <div className="pointer-events-auto mx-auto max-w-5xl">
          <DateStrip
            date={date}
            setDate={setDate}
            compareDate={compareDate}
            setCompareDate={setCompareDate}
            dated={IMAGERY[imagery].dated}
            swipeOn={swipeOn}
            setSwipeOn={setSwipeOn}
            onPickDate={pickDate}
          />
        </div>
      </div>

      <div className="pointer-events-auto absolute inset-x-0 bottom-0 z-20 flex h-[42vh] flex-col md:hidden">
        <div className="min-h-0 flex-1 overflow-y-auto border-t border-border bg-bg/95">
          {tab === "layers" ? <LeftRail {...railProps} /> : <RightRail {...rightProps} force={tab} />}
        </div>
        <div className="flex shrink-0 items-center gap-1 border-t border-border bg-bg px-2 py-1.5">
          {([
            ["log", "Log", FileText],
            ["alerts", "Queue", AlertTriangle],
            ["sites", "Sites", MapIcon],
            ["layers", "Layers", Layers],
          ] as const).map(([id, label, Icon]) => (
            <button
              key={id}
              type="button"
              onClick={() => setTab(id)}
              className={cn(
                "flex h-11 min-w-16 flex-1 flex-col items-center justify-center rounded-lg text-xs",
                tab === id ? "bg-raised text-fg" : "text-muted",
              )}
            >
              <Icon className="size-4" />
              {label}
            </button>
          ))}
        </div>
      </div>

      {helpOpen ? (
        <div className="absolute inset-0 z-40 flex items-center justify-center bg-bg/70 p-4">
          <div className="hud-panel max-h-[90dvh] w-full max-w-lg overflow-y-auto p-5">
            <p className="text-xs uppercase tracking-widest text-subtle">How this works</p>
            <h2 className="mt-1 font-display text-2xl font-medium tracking-tight">A map, a log, a sweep</h2>
            <ol className="mt-4 list-decimal space-y-3 pl-5 text-sm leading-relaxed text-muted">
              <li>
                <span className="text-fg">Pins are the 2022–2026 public archive</span> — bases, airfields, yards, camps, hospitals, crossings. Click one. <span className="text-fg">Zoom to yards</span> is the close-up.
              </li>
              <li>
                <span className="text-fg">Change log</span> is ordered by when the change first showed up (oldest first), not when a sensor last pinged. Filter Vehicles / Air-cargo / Movement.
              </li>
              <li>
                <span className="text-fg">This is documentation.</span> Party is last public report, not current occupancy. Vehicle counts are ranges. Airframes are not cargo claims. Thermal is not a strike.
              </li>
            </ol>
            <p className="mt-4 text-xs leading-relaxed text-subtle">
              Documentation archive only. No targeting, fire control, or kill-chain language. Public data.
            </p>
            <button
              type="button"
              className="mt-4 h-11 w-full rounded-xl bg-accent text-sm font-medium text-accent-fg"
              onClick={() => setHelpOpen(false)}
            >
              Got it — open the map
            </button>
          </div>
        </div>
      ) : (
        <button
          type="button"
          className="pointer-events-auto absolute bottom-28 right-[26rem] z-20 hidden size-10 items-center justify-center rounded-full border border-border bg-bg/80 text-muted hover:text-fg lg:flex"
          aria-label="How this works"
          onClick={() => setHelpOpen(true)}
        >
          <CircleHelp className="size-4" />
        </button>
      )}
    </div>
  );
}

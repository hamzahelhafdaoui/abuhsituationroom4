import { ALERTS, ARCHIVE_EVENTS, OBSERVATIONS, SITES } from "@/data/catalog";
import type { ChangeEntry, LiveBundle } from "@/lib/types";

function siteName(id?: string): string | undefined {
  if (!id) return undefined;
  return SITES.find((s) => s.id === id)?.name;
}

export function seedChangeLog(): ChangeEntry[] {
  const rows: ChangeEntry[] = ALERTS.map((a) => ({
    id: `log-${a.id}`,
    firstSeen: a.datetime,
    lastSeen: a.datetime,
    title: a.title,
    body: a.negativeEvidence ? `${a.body} Negative evidence: ${a.negativeEvidence}` : a.body,
    siteId: a.siteIds[0],
    siteName: siteName(a.siteIds[0]),
    families: a.families,
    source: "archive" as const,
    confidence: a.confidence,
    lat: a.lat,
    lon: a.lon,
    negative: Boolean(a.negativeEvidence),
  }));

  const covered = new Set(ALERTS.flatMap((a) => a.observationIds));
  for (const o of OBSERVATIONS) {
    if (covered.has(o.id)) continue;
    const site = SITES.find((s) => s.id === o.siteId);
    rows.push({
      id: `log-${o.id}`,
      firstSeen: o.datetime,
      lastSeen: o.datetime,
      title: `${site?.name ?? o.siteId} · ${o.sensor}`,
      body: o.notes,
      siteId: o.siteId,
      siteName: site?.name,
      families: o.indicators,
      source: "archive",
      confidence: o.confidence,
      lat: site?.lat ?? 0,
      lon: site?.lon ?? 0,
      negative: o.indicators.includes("thermal") && site?.kind === "farm",
    });
  }

  const have = new Set(rows.map((r) => r.id));
  for (const e of ARCHIVE_EVENTS) {
    if (have.has(e.id)) continue;
    const name = e.siteName || siteName(e.siteId);
    rows.push({ ...e, siteName: name });
    have.add(e.id);
  }

  return sortLog(rows);
}

export function sortLog(rows: ChangeEntry[]): ChangeEntry[] {
  return [...rows].sort((a, b) => {
    const c = a.firstSeen.localeCompare(b.firstSeen);
    if (c !== 0) return c;
    return a.id.localeCompare(b.id);
  });
}

function firmsIso(acqDate: string, acqTime: string): string {
  const hh = (acqTime || "0000").padStart(4, "0").slice(0, 2);
  const mm = (acqTime || "0000").padStart(4, "0").slice(2, 4);
  return `${acqDate}T${hh}:${mm}:00Z`;
}

export function ingestLive(bundle: LiveBundle, existing: ChangeEntry[]): { next: ChangeEntry[]; added: number } {
  const byId = new Map(existing.map((e) => [e.id, e]));
  let added = 0;

  const upsert = (entry: ChangeEntry) => {
    const prev = byId.get(entry.id);
    if (!prev) {
      byId.set(entry.id, entry);
      added += 1;
      return;
    }
    const firstSeen = entry.firstSeen < prev.firstSeen ? entry.firstSeen : prev.firstSeen;
    const lastSeen = entry.lastSeen > prev.lastSeen ? entry.lastSeen : prev.lastSeen;
    byId.set(entry.id, { ...prev, firstSeen, lastSeen });
  };

  const agSeen = new Set<string>();
  for (const t of bundle.firms) {
    const when = firmsIso(t.acqDate, t.acqTime);
    const name = siteName(t.siteId) ?? "unanchored";
    if (t.klass === "agricultural") {
      const dayKey = `log-firms-ag-${t.siteId ?? "none"}-${t.acqDate}`;
      if (agSeen.has(dayKey)) continue;
      agSeen.add(dayKey);
      upsert({
        id: dayKey,
        firstSeen: when,
        lastSeen: when,
        title: `Seasonal / agricultural thermal · ${name}`,
        body: `FIRMS cluster classed agricultural (FRP ${t.frp.toFixed(1)}). Default is harvest or residue burning, not combat. Negative evidence unless a later optical scene shows otherwise.`,
        siteId: t.siteId,
        siteName: siteName(t.siteId),
        families: ["thermal"],
        source: "firms",
        confidence: 2,
        lat: t.lat,
        lon: t.lon,
        negative: true,
      });
      continue;
    }
    if (!t.siteId && t.klass === "unknown") continue;
    upsert({
      id: `log-firms-${t.id}`,
      firstSeen: when,
      lastSeen: when,
      title: `Thermal anomaly · ${name}`,
      body: `VIIRS ${t.satellite} FRP ${t.frp.toFixed(1)} · class ${t.klass.replace("_", " ")} · ${t.daynight === "N" ? "night" : "day"}. Thermal anomaly is not a strike. Optical follow-up required.`,
      siteId: t.siteId,
      siteName: siteName(t.siteId),
      families: ["thermal"],
      source: "firms",
      confidence: t.klass === "possible_explosive" ? 2 : 1,
      lat: t.lat,
      lon: t.lon,
    });
  }

  for (const f of bundle.flights) {
    if (!f.relevant) continue;
    upsert({
      id: `log-fl-${f.hex}-${f.firstSeen.slice(0, 13)}`,
      firstSeen: f.firstSeen,
      lastSeen: f.lastSeen,
      title: `${f.typeCode} ${f.hex} · ${f.category}`,
      body: `${f.notes} Nearest: ${f.nearestAirfield}. Category is airframe-typical, not a cargo claim.`,
      families: ["flight"],
      source: "flight",
      confidence: f.confidence,
      lat: f.lat,
      lon: f.lon,
    });
  }

  for (const r of bundle.reports) {
    if (!r.date) continue;
    upsert({
      id: `log-${r.id}`,
      firstSeen: `${r.date}T00:00:00Z`,
      lastSeen: `${r.date}T00:00:00Z`,
      title: r.title,
      body: `${r.publisher}. Humanitarian corroboration, not ground truth. ${r.note}`,
      families: ["reporting"],
      source: "report",
      confidence: 2,
      lat: 15.6,
      lon: 32.5,
    });
  }

  return { next: sortLog([...byId.values()]), added };
}

import { ALERTS, OBSERVATIONS, SITES, WATCH_BOXES } from "@/data/catalog";
import type { FlightEvent, ThermalEvent } from "@/lib/types";
import { PARTY_LABEL } from "@/lib/types";
import { downloadBlob } from "@/lib/utils";
import { useAppStore } from "@/lib/store";

const CAVEAT = `LIMITATIONS — Sahel Record is a documentation archive, not a targeting system.
- Sentinel-2 10 m cannot distinguish pickup vs technical vs civilian 4x4.
- NASA FIRMS is a thermal-anomaly feed (375 m), not a strike feed. Agricultural burning, flares, and brick kilns are common false combat cues.
- ADS-B coverage in Sudan and adjacent desert corridors is sparse. Absence of a track is not absence of a flight. Never infer cargo contents.
- Party labels are assessments. They are not confirmed occupancy. Default new detections to confidence 1–2.
- Nothing is “confirmed” without a human review click.
- Forbidden: targeting, fire control, strike planning, kill-chain language.`;

export function exportGeoJSON() {
  const overrides = useAppStore.getState().partyOverrides;
  const fc = {
    type: "FeatureCollection" as const,
    metadata: { generated: new Date().toISOString(), caveat: CAVEAT },
    features: SITES.map((s) => ({
      type: "Feature" as const,
      geometry: { type: "Point" as const, coordinates: [s.lon, s.lat] },
      properties: {
        site_id: s.id,
        name: s.name,
        kind: s.kind,
        party: overrides[s.id]?.party ?? s.party,
        party_label: PARTY_LABEL[overrides[s.id]?.party ?? s.party],
        confidence: s.confidence,
        status: s.status,
        admin1: s.admin1,
        civilian_baseline: s.civilianBaseline,
      },
    })),
  };
  downloadBlob(
    `sahel-record-sites-${new Date().toISOString().slice(0, 10)}.geojson`,
    "application/geo+json",
    JSON.stringify(fc, null, 2),
  );
}

export function exportCsv() {
  const overrides = useAppStore.getState().partyOverrides;
  const reviews = useAppStore.getState().reviews;
  const siteLines = [
    "site_id,name,lat,lon,kind,party,confidence,status,admin1",
    ...SITES.map((s) => {
      const party = overrides[s.id]?.party ?? s.party;
      return `${s.id},"${s.name}",${s.lat},${s.lon},${s.kind},${party},${s.confidence},${s.status},"${s.admin1}"`;
    }),
  ];
  const alertLines = [
    "alert_id,type,confidence,review,lat,lon,title",
    ...ALERTS.map((a) => {
      const rev = reviews[a.id]?.state ?? a.review;
      return `${a.id},${a.type},${reviews[a.id]?.confidence ?? a.confidence},${rev},${a.lat},${a.lon},"${a.title.replace(/"/g, "'")}"`;
    }),
  ];
  const body = `# ${CAVEAT.replace(/\n/g, "\n# ")}\n\n# SITES\n${siteLines.join("\n")}\n\n# ALERTS\n${alertLines.join("\n")}\n`;
  downloadBlob(
    `sahel-record-export-${new Date().toISOString().slice(0, 10)}.csv`,
    "text/csv",
    body,
  );
}

export function briefingHtml(
  flights: FlightEvent[],
  firms: ThermalEvent[],
): string {
  const reviews = useAppStore.getState().reviews;
  const open = ALERTS.filter((a) => (reviews[a.id]?.state ?? a.review) === "unreviewed");
  return `<!doctype html>
<html><head><meta charset="utf-8"><title>Sahel Record briefing</title>
<style>
  body{font:14px/1.5 "IBM Plex Sans",system-ui;color:#1a1916;background:#f6f1e8;margin:32px auto;max-width:720px}
  h1{font:600 28px/1.2 Newsreader,Georgia,serif;margin:0 0 8px}
  .kicker{letter-spacing:.14em;text-transform:uppercase;font-size:11px;color:#6a645a}
  .caveat{border:1px solid #c9c1b2;padding:12px 14px;margin:18px 0;font-size:12px;white-space:pre-wrap}
  h2{font-size:16px;margin:28px 0 8px}
  li{margin:6px 0}
  footer{margin-top:32px;font-size:11px;color:#6a645a}
</style></head><body>
<p class="kicker">Sahel Record · documentation briefing</p>
<h1>Sudan & adjacent corridors</h1>
<p>${new Date().toISOString().slice(0, 16).replace("T", " ")}Z · public data only · no targeting</p>
<div class="caveat">${CAVEAT}</div>
<h2>Unreviewed alerts (${open.length})</h2>
<ol>${open.map((a) => `<li><strong>${a.title}</strong> — ${a.body} Confidence ${a.confidence}/5.</li>`).join("")}</ol>
<h2>Watch boxes</h2>
<ul>${WATCH_BOXES.map((b) => `<li>${b.name} — ${b.notes}</li>`).join("")}</ul>
<h2>Live ingest snapshot</h2>
<p>FIRMS points in AOI this cycle: ${firms.length}. Live flights: ${flights.filter((f) => f.live).length}. Observations in archive: ${OBSERVATIONS.length}.</p>
<h2>Methods appendix</h2>
<p>Optical browse via NASA GIBS (VIIRS / HLS). Thermal from NASA FIRMS VIIRS 375 m. Flights from public ADS-B aggregators (adsb.lol, adsb.fi) with OpenSky fallback. Humanitarian corroboration via ReliefWeb. Human review required. Default new detections to confidence 1–2.</p>
<footer>Sahel Record · civilian archive · every page carries this caveat.</footer>
</body></html>`;
}

export function exportBriefing(flights: FlightEvent[], firms: ThermalEvent[]) {
  const html = briefingHtml(flights, firms);
  const w = window.open("", "_blank", "noopener,noreferrer");
  if (!w) {
    downloadBlob(`sahel-record-briefing.html`, "text/html", html);
    return;
  }
  w.document.write(html);
  w.document.close();
  w.focus();
  w.print();
}

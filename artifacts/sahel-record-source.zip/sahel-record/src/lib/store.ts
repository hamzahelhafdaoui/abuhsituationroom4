import { create } from "zustand";
import { persist } from "zustand/middleware";
import { ALERTS, WATCH_BOXES } from "@/data/catalog";
import { seedChangeLog, sortLog } from "@/lib/changelog";
import { daysAgo } from "@/lib/utils";
import type {
  AuditEntry,
  ChangeEntry,
  Confidence,
  ImagerySource,
  Party,
  ReviewState,
  WatchBox,
} from "@/lib/types";

export type LayerKey =
  | "sites"
  | "firms"
  | "flights"
  | "boxes"
  | "gibs"
  | "thermalRaster";

interface Review {
  state: ReviewState;
  note: string;
  confidence: Confidence;
  at: string;
}

interface PartyOverride {
  party: Party;
  reason: string;
  at: string;
}

interface AppState {
  selectedSiteId: string | null;
  selectedAlertId: string | null;
  focusedBoxId: string | null;
  yardsZoom: boolean;
  partyFilter: Party | "all";
  kindFilter: string;
  reviewFilter: ReviewState | "all";
  layers: Record<LayerKey, boolean>;
  imagery: ImagerySource;
  date: string;
  compareDate: string;
  swipeOn: boolean;
  query: string;
  reviews: Record<string, Review>;
  partyOverrides: Record<string, PartyOverride>;
  customBoxes: WatchBox[];
  hiddenBoxIds: string[];
  audit: AuditEntry[];
  changeLog: ChangeEntry[];
  lastSweepAt: string | null;
  helpOpen: boolean;
  setSelectedSite: (id: string | null) => void;
  setSelectedAlert: (id: string | null) => void;
  setFocusedBox: (id: string | null) => void;
  requestYardsZoom: () => void;
  clearYardsZoom: () => void;
  setPartyFilter: (p: Party | "all") => void;
  setKindFilter: (k: string) => void;
  setReviewFilter: (r: ReviewState | "all") => void;
  toggleLayer: (k: LayerKey) => void;
  setImagery: (i: ImagerySource) => void;
  setDate: (d: string) => void;
  setCompareDate: (d: string) => void;
  setSwipeOn: (v: boolean) => void;
  setQuery: (q: string) => void;
  reviewAlert: (id: string, state: ReviewState, note: string, confidence: Confidence) => void;
  overrideParty: (siteId: string, party: Party, reason: string) => void;
  addBox: (box: WatchBox) => void;
  removeBox: (id: string) => void;
  hideDefaultBox: (id: string) => void;
  replaceLog: (rows: ChangeEntry[]) => void;
  setLastSweepAt: (iso: string) => void;
  setHelpOpen: (v: boolean) => void;
}

function stamp(): string {
  return new Date().toISOString();
}

function audit(action: string, target: string, reason: string): AuditEntry {
  return {
    id: `aud-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
    at: stamp(),
    actor: "local-analyst",
    action,
    target,
    reason,
  };
}

const defaultReviews: Record<string, Review> = {};
for (const a of ALERTS) {
  if (a.review !== "unreviewed") {
    defaultReviews[a.id] = {
      state: a.review,
      note: a.negativeEvidence || "Seeded review from archive.",
      confidence: a.confidence,
      at: a.datetime,
    };
  }
}

export const useAppStore = create<AppState>()(
  persist(
    (set) => ({
      selectedSiteId: null,
      selectedAlertId: null,
      focusedBoxId: null,
      yardsZoom: false,
      partyFilter: "all",
      kindFilter: "all",
      reviewFilter: "all",
      layers: {
        sites: true,
        firms: true,
        flights: true,
        boxes: true,
        gibs: true,
        thermalRaster: false,
      },
      imagery: "s2cloudless",
      date: daysAgo(4),
      compareDate: daysAgo(14),
      swipeOn: false,
      query: "",
      reviews: defaultReviews,
      partyOverrides: {},
      customBoxes: [],
      hiddenBoxIds: [],
      audit: [],
      changeLog: seedChangeLog(),
      lastSweepAt: null,
      helpOpen: true,
      setSelectedSite: (id) => set({ selectedSiteId: id, focusedBoxId: null }),
      setSelectedAlert: (id) => set({ selectedAlertId: id }),
      setFocusedBox: (id) => set({ focusedBoxId: id, selectedSiteId: null, selectedAlertId: null }),
      requestYardsZoom: () => set({ yardsZoom: true, imagery: "hires" }),
      clearYardsZoom: () => set({ yardsZoom: false }),
      setPartyFilter: (p) => set({ partyFilter: p }),
      setKindFilter: (k) => set({ kindFilter: k }),
      setReviewFilter: (r) => set({ reviewFilter: r }),
      toggleLayer: (k) => set((s) => ({ layers: { ...s.layers, [k]: !s.layers[k] } })),
      setImagery: (i) => set({ imagery: i }),
      setDate: (d) => set({ date: d }),
      setCompareDate: (d) => set({ compareDate: d }),
      setSwipeOn: (v) => set({ swipeOn: v }),
      setQuery: (q) => set({ query: q }),
      reviewAlert: (id, state, note, confidence) =>
        set((s) => ({
          reviews: {
            ...s.reviews,
            [id]: { state, note, confidence, at: stamp() },
          },
          audit: [
            audit("review-alert", id, `${state} · c${confidence} · ${note || "no note"}`),
            ...s.audit,
          ].slice(0, 200),
        })),
      overrideParty: (siteId, party, reason) =>
        set((s) => ({
          partyOverrides: {
            ...s.partyOverrides,
            [siteId]: { party, reason, at: stamp() },
          },
          audit: [audit("party-label", siteId, `${party} · ${reason}`), ...s.audit].slice(0, 200),
        })),
      addBox: (box) =>
        set((s) => ({
          customBoxes: [...s.customBoxes, box],
          audit: [audit("watchbox-add", box.id, box.name), ...s.audit].slice(0, 200),
        })),
      removeBox: (id) =>
        set((s) => ({
          customBoxes: s.customBoxes.filter((b) => b.id !== id),
          audit: [audit("watchbox-remove", id, "removed custom box"), ...s.audit].slice(0, 200),
        })),
      hideDefaultBox: (id) =>
        set((s) => ({
          hiddenBoxIds: [...s.hiddenBoxIds, id],
          audit: [audit("watchbox-hide", id, "hid default box"), ...s.audit].slice(0, 200),
        })),
      replaceLog: (rows) => set({ changeLog: sortLog(rows) }),
      setLastSweepAt: (iso) => set({ lastSweepAt: iso }),
      setHelpOpen: (v) => set({ helpOpen: v }),
    }),
    {
      name: "sahel-record-v5",
      partialize: (s) => ({
        reviews: s.reviews,
        partyOverrides: s.partyOverrides,
        customBoxes: s.customBoxes,
        hiddenBoxIds: s.hiddenBoxIds,
        audit: s.audit,
        imagery: s.imagery,
        changeLog: s.changeLog,
        lastSweepAt: s.lastSweepAt,
        helpOpen: s.helpOpen,
      }),
      merge: (persisted, current) => {
        const p = (persisted ?? {}) as Partial<AppState>;
        const seeded = seedChangeLog();
        const have = new Map((p.changeLog ?? []).map((e) => [e.id, e]));
        for (const row of seeded) {
          if (!have.has(row.id)) have.set(row.id, row);
        }
        return {
          ...current,
          ...p,
          changeLog: sortLog([...have.values()]),
        };
      },
    },
  ),
);

export function useVisibleBoxes(): WatchBox[] {
  const custom = useAppStore((s) => s.customBoxes);
  const hidden = useAppStore((s) => s.hiddenBoxIds);
  return [...WATCH_BOXES.filter((b) => !hidden.includes(b.id)), ...custom];
}

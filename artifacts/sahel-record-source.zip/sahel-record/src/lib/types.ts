export type ImagerySource = "s2" | "viirs" | "s2cloudless" | "hires";

export const IMAGERY: Record<
  ImagerySource,
  { label: string; grain: string; dated: boolean; note: string }
> = {
  s2: {
    label: "Sentinel-2",
    grain: "HLS 30 m · dated",
    dated: true,
    note: "NASA HLS from Sentinel-2 MSI. ~30 m. Not every day; cloudy granules are empty. Latency about 2–4 days.",
  },
  viirs: {
    label: "VIIRS daily",
    grain: "250 m · dated",
    dated: true,
    note: "NASA GIBS NOAA-20 true color. Coarse. Today is often incomplete.",
  },
  s2cloudless: {
    label: "S2 cloudless",
    grain: "mosaic · not a date",
    dated: false,
    note: "EOX Sentinel-2 cloudless 2024 mosaic. Morphology, not a single overpass. Do not date a change to 2024.",
  },
  hires: {
    label: "High-res",
    grain: "yards / roofs",
    dated: false,
    note: "Esri World Imagery. Best for yards and roofs. Not a dated scene.",
  },
};

export type Party =
  | "saf"
  | "rsf"
  | "mixed"
  | "other_armed"
  | "civilian"
  | "unknown";

export type SiteStatus = "active" | "damaged" | "abandoned" | "unclear";

export type Confidence = 1 | 2 | 3 | 4 | 5;

export type ReviewState =
  | "unreviewed"
  | "confirmed"
  | "rejected"
  | "needs_imagery";

export type AlertType =
  | "change"
  | "thermal"
  | "flight"
  | "convoy"
  | "damage"
  | "multi_source";

export type AirCategory = "pax" | "cargo" | "bizjet" | "tanker" | "unknown";

export type ThermalClass =
  | "agricultural"
  | "industrial"
  | "urban_structure"
  | "possible_explosive"
  | "unknown";

export type IndicatorFamily =
  | "morphology"
  | "thermal"
  | "flight"
  | "vehicles"
  | "damage"
  | "reporting"
  | "corridor";

export interface WatchBox {
  id: string;
  name: string;
  region: string;
  west: number;
  south: number;
  east: number;
  north: number;
  priority: "primary" | "border";
  notes: string;
}

export interface Site {
  id: string;
  name: string;
  lat: number;
  lon: number;
  admin1: string;
  admin2: string;
  kind:
    | "airfield"
    | "compound"
    | "logistics"
    | "market"
    | "hospital"
    | "camp"
    | "farm"
    | "crossing"
    | "strip"
    | "port"
    | "well";
  party: Party;
  confidence: Confidence;
  firstSeen: string;
  lastSeen: string;
  status: SiteStatus;
  civilianBaseline: string;
  notes: string;
}

export const KIND_GROUPS: Record<string, Site["kind"][] | null> = {
  all: null,
  bases: ["airfield", "strip", "compound"],
  yards: ["logistics", "port"],
  camps: ["camp"],
  hospitals: ["hospital"],
  markets: ["market"],
  corridors: ["crossing", "well"],
};

export const KIND_GROUP_LABEL: Record<string, string> = {
  all: "All pins",
  bases: "Bases / airfields",
  yards: "Yards / cargo",
  camps: "Camps",
  hospitals: "Hospitals",
  markets: "Markets",
  corridors: "Corridors",
};

export function siteInKindGroup(kind: Site["kind"], group: string): boolean {
  const g = KIND_GROUPS[group];
  if (!g) return true;
  return g.includes(kind);
}

export interface VehicleEstimate {
  large: [number, number];
  uncertainNote: string;
}

export interface Observation {
  id: string;
  siteId: string;
  datetime: string;
  sensor: string;
  sceneId: string;
  cloudPct: number;
  notes: string;
  indicators: IndicatorFamily[];
  vehicles?: VehicleEstimate;
  damageFlag: boolean;
  confidence: Confidence;
}

export interface Alert {
  id: string;
  type: AlertType;
  score: number;
  title: string;
  body: string;
  siteIds: string[];
  observationIds: string[];
  lat: number;
  lon: number;
  datetime: string;
  families: IndicatorFamily[];
  confidence: Confidence;
  review: ReviewState;
  negativeEvidence?: string;
}

export interface FlightEvent {
  id: string;
  hex: string;
  reg: string;
  typeCode: string;
  operator: string;
  category: AirCategory;
  origin: string;
  dest: string;
  firstSeen: string;
  lastSeen: string;
  lat: number;
  lon: number;
  altFt?: number;
  track?: number;
  gs?: number;
  nearestAirfield: string;
  notes: string;
  confidence: Confidence;
  relevant: boolean;
  live?: boolean;
}

export interface ThermalEvent {
  id: string;
  lat: number;
  lon: number;
  acqDate: string;
  acqTime: string;
  satellite: string;
  confidence: string;
  frp: number;
  daynight: "D" | "N";
  klass: ThermalClass;
  siteId?: string;
  live?: boolean;
}

export interface Citation {
  id: string;
  title: string;
  publisher: string;
  date: string;
  url: string;
  reliability: "high" | "medium" | "low";
  note: string;
}

export interface ChangeEntry {
  id: string;
  firstSeen: string;
  lastSeen: string;
  title: string;
  body: string;
  siteId?: string;
  siteName?: string;
  families: IndicatorFamily[];
  source: "archive" | "firms" | "flight" | "report";
  confidence: Confidence;
  lat: number;
  lon: number;
  negative?: boolean;
}

export interface AuditEntry {
  id: string;
  at: string;
  actor: string;
  action: string;
  target: string;
  reason: string;
}

export interface LiveMeta {
  fetchedAt: string | null;
  recordCount: number;
  status: "ok" | "stale" | "empty" | "error" | "gap";
  source: string;
  note: string;
}

export interface LiveBundle {
  firms: ThermalEvent[];
  firmsMeta: LiveMeta;
  flights: FlightEvent[];
  flightsMeta: LiveMeta;
  reports: Citation[];
  reportsMeta: LiveMeta;
}

export const PARTY_LABEL: Record<Party, string> = {
  saf: "SAF",
  rsf: "RSF",
  mixed: "Mixed",
  other_armed: "Other armed",
  civilian: "Civilian",
  unknown: "Unknown",
};

export const CONFIDENCE_RUBRIC: Record<Confidence, string> = {
  1: "Single weak indicator (one cloudy-adjacent change, one FIRMS point, one overflight).",
  2: "Repeated same indicator, no independent corroboration.",
  3: "Two indicator families, same site, multi-date.",
  4: "Three families plus open-source reporting that is consistent.",
  5: "High-res or ground media + multi-date satellite + reporting + movement chain.",
};

export const AOI = {
  west: 20.2,
  south: 8.4,
  east: 39.2,
  north: 24.8,
  center: [30.15, 15.55] as [number, number],
  zoom: 5.15,
};

import { createFileRoute } from "@tanstack/react-router";
import { DocPage } from "@/components/doc-page";

export const Route = createFileRoute("/methods")({ component: Methods });

function Methods() {
  return (
    <DocPage kicker="Methods appendix" title="How this archive sees, and what it cannot see">
      <p>
        Sahel Record uses only publicly available satellite browse, thermal anomaly feeds, and
        unfiltered-or-public ADS-B aggregators. It is a documentation workbench for journalists,
        researchers, human-rights archivists, and humanitarian analysts. It is not a fire-control
        system.
      </p>

      <h2>Optical browse</h2>
      <p>
        Four public stacks, switched in the workspace: <strong>Sentinel-2 HLS</strong> (NASA
        GIBS <code>HLS_S30_Nadir_BRDF_Adjusted_Reflectance</code>, GoogleMapsCompatible Level 12,
        ~30 m, dated, latency typically 2–4 days), <strong>VIIRS daily</strong> (NOAA-20 true color,
        ~250 m), <strong>Sentinel-2 cloudless</strong> (EOX 2024 mosaic — morphology only, not a
        dated overpass), and <strong>high-res</strong> (Esri World Imagery for yards and roofs).
        HLS granules are not global every day; empty or cloudy tiles stay empty. Higher-resolution
        change notes in the archive still assume Sentinel-2 L2A at 10 m when an analyst has a
        lawfully obtained scene. Commercial Maxar/Airbus/Planet is not scraped.
      </p>
      <p>
        Object counting at 10 m is an estimate band, not a census. The interface stores ranges
        (for example 12–25 large vehicles) and states that pickups, technicals, and civilian 4x4s
        are not separable at this resolution.
      </p>

      <h2>Thermal / FIRMS</h2>
      <p>
        NASA FIRMS VIIRS 375 m (NOAA-20 and NOAA-21 24-hour public CSVs) is ingested server-side,
        clipped to the Sudan-plus-corridors AOI, and deduped. FIRMS is a thermal-anomaly feed, not
        a strike feed. Each point is classified agricultural, industrial, urban structure fire,
        possible explosive/combat-related, or unknown. Combat-related labels above “possible”
        require optical follow-up. Agricultural burning, oil flares, brick kilns, and gas flares
        are first-class negative evidence.
      </p>

      <h2>Flights</h2>
      <p>
        Live positions are requested from public ADS-B aggregators (adsb.lol, then adsb.fi) with
        OpenSky Network as a last-resort anonymous bbox query — the same public-source cascade
        documented by open dashboards such as World Monitor, reimplemented here without copying
        their code. We log registration, ICAO hex, type, operator if known, time over the AOI, and
        nearest airfield. We never claim cargo. Category (pax / cargo / bizjet / tanker / unknown)
        is typical for the airframe.
      </p>
      <p>
        ADS-B coverage in Darfur, Kordofan, Blue Nile, and the Libya desert tracks is sparse.
        Absence of a track is not absence of a flight. Coverage gaps are marked on the health
        chips. Scheduled passenger services are low priority unless they divert to unusual fields.
      </p>

      <h2>Alerts</h2>
      <p>
        An alert card opens only when two or more indicator families co-occur, or when change
        exceeds a threshold the analyst set. Auto-text stays observational. Nothing is labelled
        “confirmed” without a human click. Default new detections to confidence 1 or 2.
      </p>

      <h2>Confidence rubric</h2>
      <ol className="list-decimal space-y-1 pl-5">
        <li>Single weak indicator.</li>
        <li>Repeated same indicator, no corroboration.</li>
        <li>Two indicator families, same site, multi-date.</li>
        <li>Three families plus consistent open-source reporting.</li>
        <li>High-res or ground media + multi-date satellite + reporting + movement chain.</li>
      </ol>

      <h2>Reproducibility</h2>
      <p>
        Each observation stores sensor, scene ID, time, cloud percentage, notes, indicator
        families, and confidence. Exports (GeoJSON, CSV, briefing) print a limitations footer on
        every page. Party-label changes write an audit row with reason.
      </p>

      <h2>What we pulled from open dashboards</h2>
      <p>
        World Monitor (koala73/worldmonitor, AGPL) is a useful map of public sources: NASA FIRMS,
        ADS-B aggregators, OpenSky, GIBS-class browse, ACLED/UCDP as corroboration. This archive
        reuses those public contracts — gold-standard server-side ingest, freshness metadata,
        coverage-gap warnings — and does not copy their application code or targeting-adjacent
        language. Their military-flight seeder is intentionally not reproduced; we classify
        airframes, we do not hunt a party.
      </p>
    </DocPage>
  );
}
